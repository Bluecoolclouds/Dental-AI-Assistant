import { useState } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { HomeScreen } from './components/HomeScreen';
import { MedicalRecordScreen } from './components/MedicalRecordScreen';
import { CalendarScreen } from './components/CalendarScreen';
import { ProfileScreen } from './components/ProfileScreen';

type Screen = 'splash' | 'home' | 'records' | 'calendar' | 'profile';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');

  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-md h-full bg-white shadow-2xl overflow-auto">
        {currentScreen === 'splash' && (
          <SplashScreen onGetStarted={() => setCurrentScreen('home')} />
        )}
        {currentScreen === 'home' && (
          <HomeScreen 
            onNavigateToRecords={() => setCurrentScreen('records')}
            onNavigateToCalendar={() => setCurrentScreen('calendar')}
            onNavigateToProfile={() => setCurrentScreen('profile')}
          />
        )}
        {currentScreen === 'records' && (
          <MedicalRecordScreen 
            onBack={() => setCurrentScreen('home')}
            onNavigateToCalendar={() => setCurrentScreen('calendar')}
          />
        )}
        {currentScreen === 'calendar' && (
          <CalendarScreen onBack={() => setCurrentScreen('home')} />
        )}
        {currentScreen === 'profile' && (
          <ProfileScreen 
            onBack={() => setCurrentScreen('home')}
            onNavigateToRecords={() => setCurrentScreen('records')}
            onNavigateToCalendar={() => setCurrentScreen('calendar')}
          />
        )}
      </div>
    </div>
  );
}