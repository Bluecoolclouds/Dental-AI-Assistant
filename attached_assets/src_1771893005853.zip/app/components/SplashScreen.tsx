import { ChevronLeft, ChevronRight } from 'lucide-react';

interface SplashScreenProps {
  onGetStarted: () => void;
}

export function SplashScreen({ onGetStarted }: SplashScreenProps) {
  return (
    <div className="h-screen w-full bg-gradient-to-b from-[#4A90D9] to-[#7AADE6] flex flex-col items-center justify-between p-8 overflow-hidden relative">
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-64 h-64 rounded-full border border-white/10 -translate-y-1/2 translate-x-1/3"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full border border-white/10 translate-y-1/3 -translate-x-1/4"></div>
      
      {/* Header */}
      <div className="text-white text-center mt-8">
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
              <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z" fill="#4A90D9"/>
              <path d="M8 10c0-.5.5-1 1-1s1 .5 1 1-.5 1-1 1-1-.5-1-1zm6 0c0-.5.5-1 1-1s1 .5 1 1-.5 1-1 1-1-.5-1-1zm-6 4h8c0 2.2-1.8 4-4 4s-4-1.8-4-4z" fill="white"/>
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold">Dentcor</h1>
            <p className="text-xs tracking-wider opacity-90">DENTAL CARE</p>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center text-center text-white px-4">
        <h2 className="text-4xl font-bold mb-4 leading-tight">
          Feel Amazing About<br />Your Oral Health
        </h2>
        <p className="text-white/80 text-sm max-w-xs">
          Clinical excellence must be the priority for any health care service provider
        </p>
      </div>

      {/* Tooth illustration */}
      <div className="relative w-full max-w-md mb-8">
        <div className="flex justify-center gap-6">
          <div className="w-32 h-40 bg-white/20 backdrop-blur-sm rounded-t-full rounded-b-lg"></div>
          <div className="w-32 h-40 bg-white/20 backdrop-blur-sm rounded-t-full rounded-b-lg"></div>
        </div>
      </div>

      {/* Navigation buttons */}
      <div className="flex gap-4 mb-8">
        <button className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors">
          <ChevronLeft size={24} />
        </button>
        <button 
          onClick={onGetStarted}
          className="px-8 h-12 bg-white rounded-full flex items-center gap-2 text-[#4A90D9] font-semibold hover:bg-white/90 transition-colors"
        >
          Book Now
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
}
