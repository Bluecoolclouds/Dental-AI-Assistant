import { Bell, Phone, ChevronRight, Star, Home, Calendar, FileText, MessageCircle, User, MapPin, ClipboardList, Lightbulb, UserCircle } from 'lucide-react';

interface HomeScreenProps {
  onNavigateToRecords: () => void;
  onNavigateToCalendar: () => void;
  onNavigateToProfile: () => void;
}

export function HomeScreen({ onNavigateToRecords, onNavigateToCalendar, onNavigateToProfile }: HomeScreenProps) {
  const quickActions = [
    { name: 'Карта зубов', icon: MapPin, color: 'bg-blue-50', iconColor: 'text-blue-500', onClick: onNavigateToRecords },
    { name: 'Пройти тест', icon: ClipboardList, color: 'bg-purple-50', iconColor: 'text-purple-500', onClick: () => {} },
    { name: 'ИИ советы', icon: Lightbulb, color: 'bg-yellow-50', iconColor: 'text-yellow-500', onClick: () => {} },
    { name: 'Профиль', icon: UserCircle, color: 'bg-green-50', iconColor: 'text-green-500', onClick: onNavigateToProfile },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 rounded-b-3xl shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full"></div>
            <div>
              <p className="text-sm text-gray-500">Hello 👋</p>
              <p className="text-lg font-bold text-[#4A90D9]">Monica Wood</p>
            </div>
          </div>
          <button className="w-10 h-10 border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors">
            <Bell size={20} className="text-gray-600" />
          </button>
        </div>

        {/* Special Offer Card */}
        <div className="bg-gradient-to-br from-[#5B9FE3] to-[#4A8FD3] rounded-3xl p-6 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4"></div>
          
          <div className="relative z-10">
            <div className="inline-block bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold mb-3">
              SPECIAL OFFER
            </div>
            <p className="text-2xl font-bold mb-1">Get 60% Off On</p>
            <p className="text-sm opacity-90 mb-4">Selected Dental Total</p>
            
            <button className="bg-white text-[#4A90D9] px-6 py-2 rounded-full font-semibold flex items-center gap-2 hover:bg-gray-50 transition-colors">
              <Phone size={16} />
              Call Now
            </button>
          </div>

          {/* Tooth character illustration placeholder */}
          <div className="absolute right-4 top-1/2 -translate-y-1/2 w-24 h-24 bg-white/10 rounded-full"></div>
        </div>
      </div>

      {/* Быстрые действия */}
      <div className="px-6 mt-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900">Быстрые действия</h2>
        </div>
        
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action) => (
            <button
              key={action.name}
              onClick={action.onClick}
              className="flex flex-col items-center gap-2 p-3 bg-white rounded-2xl hover:shadow-md transition-shadow"
            >
              <div className={`w-16 h-16 ${action.color} rounded-xl flex items-center justify-center`}>
                <action.icon size={24} className={action.iconColor} />
              </div>
              <span className="text-xs font-medium text-gray-700 text-center leading-tight">{action.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Available Doctor */}
      <div className="px-6 mt-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900">Available Doctor</h2>
          <button className="text-gray-400 hover:text-gray-600">
            <ChevronRight size={24} />
          </button>
        </div>

        <div className="bg-white rounded-3xl p-4 shadow-sm">
          <div className="flex gap-4">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl flex-shrink-0"></div>
            
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-gray-900">Dr. Phos Gray</h3>
                <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                  <svg viewBox="0 0 24 24" fill="white" className="w-3 h-3">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
              </div>
              
              <div className="flex items-center gap-2 text-xs text-gray-500 mb-1">
                <span>Orthodontist</span>
                <span>•</span>
                <span>11 km</span>
              </div>
              
              <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                Dr. Phos is a genius in all arts of doctory, she is truly a...
              </p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={12} className={i < 4 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"} />
                  ))}
                  <span className="text-xs font-semibold text-gray-700 ml-1">4.5</span>
                  <span className="text-xs text-gray-400">• 1.2k</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 rounded-t-3xl shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button className="flex flex-col items-center gap-1 px-4 py-2 bg-[#4A90D9] text-white rounded-2xl">
            <Home size={20} />
            <span className="text-xs font-medium">Home</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600" onClick={onNavigateToRecords}>
            <FileText size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <MessageCircle size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600" onClick={onNavigateToCalendar}>
            <Calendar size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600" onClick={onNavigateToProfile}>
            <User size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}