import { ChevronLeft, Home, Calendar, FileText, MessageCircle, User } from 'lucide-react';

interface MedicalRecordScreenProps {
  onBack: () => void;
  onNavigateToCalendar: () => void;
}

export function MedicalRecordScreen({ onBack, onNavigateToCalendar }: MedicalRecordScreenProps) {
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 flex items-center gap-4">
        <button 
          onClick={onBack}
          className="w-10 h-10 border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors"
        >
          <ChevronLeft size={20} className="text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-[#4A90D9]">Your Medical Record</h1>
      </div>

      {/* Status indicators */}
      <div className="px-6 mt-6">
        <div className="bg-white rounded-3xl p-6">
          <div className="space-y-3 mb-8">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
              <span className="text-sm text-gray-700">Has Treatment Before</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm text-gray-700">Recommended To Be Treated</span>
            </div>
          </div>

          {/* Dental Arch Diagram */}
          <div className="relative">
            <svg viewBox="0 0 300 400" className="w-full">
              {/* Upper arch label */}
              <text x="150" y="30" textAnchor="middle" className="text-xs fill-gray-600">Upper Dental Arch</text>
              
              {/* Upper teeth */}
              <ellipse cx="150" cy="100" rx="120" ry="60" fill="none" stroke="#e5e7eb" strokeWidth="2"/>
              
              {/* Upper teeth - individual teeth */}
              {[...Array(14)].map((_, i) => {
                const angle = (i * 180 / 13) - 90;
                const x = 150 + 110 * Math.cos(angle * Math.PI / 180);
                const y = 100 + 50 * Math.sin(angle * Math.PI / 180);
                const isYellow = i === 1 || i === 12;
                
                return (
                  <g key={`upper-${i}`}>
                    <rect
                      x={x - 10}
                      y={y - 12}
                      width="20"
                      height="24"
                      rx="8"
                      fill={isYellow ? "#fbbf24" : "#f3f4f6"}
                      stroke="#d1d5db"
                      strokeWidth="1"
                    />
                  </g>
                );
              })}

              {/* Lower arch label */}
              <text x="150" y="280" textAnchor="middle" className="text-xs fill-gray-600">Lower Dental Arch</text>
              
              {/* Lower teeth */}
              <ellipse cx="150" cy="340" rx="120" ry="60" fill="none" stroke="#e5e7eb" strokeWidth="2"/>
              
              {/* Lower teeth - individual teeth */}
              {[...Array(14)].map((_, i) => {
                const angle = (i * 180 / 13) + 90;
                const x = 150 + 110 * Math.cos(angle * Math.PI / 180);
                const y = 340 + 50 * Math.sin(angle * Math.PI / 180);
                const isYellow = i === 0 || i === 13;
                
                return (
                  <g key={`lower-${i}`}>
                    <rect
                      x={x - 10}
                      y={y - 12}
                      width="20"
                      height="24"
                      rx="8"
                      fill={isYellow ? "#fbbf24" : "#f3f4f6"}
                      stroke="#d1d5db"
                      strokeWidth="1"
                    />
                  </g>
                );
              })}

              {/* Info callout */}
              <g>
                <rect x="20" y="220" width="140" height="40" rx="12" fill="white" stroke="#e5e7eb" strokeWidth="1"/>
                <text x="90" y="235" textAnchor="middle" className="text-[10px] fill-gray-700">This Can Lead To A Small Hole</text>
                <text x="90" y="248" textAnchor="middle" className="text-[10px] fill-gray-700">In A Tooth, Called A Cavity.</text>
                
                {/* Pointer dot */}
                <circle cx="200" cy="240" r="6" fill="#3b82f6"/>
              </g>
            </svg>
          </div>
        </div>
      </div>

      {/* Doctor illustration placeholder */}
      <div className="fixed bottom-20 right-6 w-32 h-32 bg-gradient-to-br from-blue-100 to-blue-200 rounded-3xl shadow-lg"></div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 rounded-t-3xl shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button 
            onClick={onBack}
            className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600"
          >
            <Home size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-2 bg-[#4A90D9] text-white rounded-2xl">
            <FileText size={20} />
            <span className="text-xs font-medium">Records</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <MessageCircle size={20} />
          </button>
          <button 
            onClick={onNavigateToCalendar}
            className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600"
          >
            <Calendar size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <User size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}