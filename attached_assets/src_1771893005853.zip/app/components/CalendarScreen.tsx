import { ChevronLeft, ChevronRight, Home, Calendar, FileText, MessageCircle, User } from 'lucide-react';
import { useState } from 'react';

interface CalendarScreenProps {
  onBack: () => void;
}

export function CalendarScreen({ onBack }: CalendarScreenProps) {
  const [selectedDate, setSelectedDate] = useState(15);
  const [selectedTime, setSelectedTime] = useState('09:00 AM');

  const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dates = Array.from({ length: 31 }, (_, i) => i + 1);
  
  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM',
    '05:00 PM', '06:00 PM'
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={onBack}
            className="w-10 h-10 border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors"
          >
            <ChevronLeft size={20} className="text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-[#4A90D9]">Book Appointment</h1>
        </div>

        {/* Month selector */}
        <div className="flex items-center justify-between mb-4">
          <button className="w-10 h-10 border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors">
            <ChevronLeft size={20} className="text-gray-600" />
          </button>
          <h2 className="text-lg font-bold text-gray-900">February 2026</h2>
          <button className="w-10 h-10 border-2 border-gray-200 rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors">
            <ChevronRight size={20} className="text-gray-600" />
          </button>
        </div>

        {/* Days of week */}
        <div className="grid grid-cols-7 gap-2 mb-4">
          {daysOfWeek.map((day) => (
            <div key={day} className="text-center text-xs font-medium text-gray-500">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar dates */}
        <div className="grid grid-cols-7 gap-2">
          {/* Empty cells for alignment (Feb 2026 starts on Sunday) */}
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          
          {dates.map((date) => {
            const isSelected = date === selectedDate;
            const isToday = date === 18;
            const isPast = date < 18;
            
            return (
              <button
                key={date}
                onClick={() => !isPast && setSelectedDate(date)}
                disabled={isPast}
                className={`
                  aspect-square rounded-xl flex items-center justify-center text-sm font-medium transition-all
                  ${isSelected 
                    ? 'bg-[#4A90D9] text-white shadow-md scale-105' 
                    : isToday
                    ? 'bg-blue-50 text-[#4A90D9] border-2 border-[#4A90D9]'
                    : isPast
                    ? 'text-gray-300 cursor-not-allowed'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }
                `}
              >
                {date}
              </button>
            );
          })}
        </div>
      </div>

      {/* Available time slots */}
      <div className="px-6 mt-6">
        <h2 className="text-lg font-bold text-gray-900 mb-4">Available Time</h2>
        <div className="grid grid-cols-3 gap-3">
          {timeSlots.map((time) => {
            const isSelected = time === selectedTime;
            const isBooked = time === '11:00 AM' || time === '02:00 PM';
            
            return (
              <button
                key={time}
                onClick={() => !isBooked && setSelectedTime(time)}
                disabled={isBooked}
                className={`
                  py-3 px-4 rounded-2xl text-sm font-medium transition-all
                  ${isSelected
                    ? 'bg-[#4A90D9] text-white shadow-md'
                    : isBooked
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
                  }
                `}
              >
                {time}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected doctor card */}
      <div className="px-6 mt-6">
        <h2 className="text-lg font-bold text-gray-900 mb-4">Selected Doctor</h2>
        <div className="bg-white rounded-3xl p-4 shadow-sm">
          <div className="flex gap-4">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl flex-shrink-0"></div>
            
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-gray-900">Dr. Phos Gray</h3>
                <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                  <svg viewBox="0 0 24 24" fill="white" className="w-3 h-3">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
              </div>
              
              <p className="text-sm text-gray-500 mb-2">Orthodontist</p>
              
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-[#4A90D9]">Rating: 4.5</span>
                <span className="text-xs text-gray-400">• 11 km away</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Book button */}
      <div className="fixed bottom-20 left-0 right-0 px-6">
        <button className="w-full bg-gradient-to-r from-[#5B9FE3] to-[#4A8FD3] text-white py-4 rounded-full font-bold text-lg shadow-xl hover:shadow-2xl transition-all">
          Confirm Appointment
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 rounded-t-3xl shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button 
            onClick={onBack}
            className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600"
          >
            <Home size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <FileText size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <MessageCircle size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-2 bg-[#4A90D9] text-white rounded-2xl">
            <Calendar size={20} />
            <span className="text-xs font-medium">Calendar</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <User size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
