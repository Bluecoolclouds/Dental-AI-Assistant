import { ChevronRight, Home, Calendar, FileText, MessageCircle, User, Bell, Heart, CreditCard, Settings, HelpCircle, LogOut, Camera, ClipboardCheck } from 'lucide-react';

interface ProfileScreenProps {
  onBack: () => void;
  onNavigateToRecords: () => void;
  onNavigateToCalendar: () => void;
}

export function ProfileScreen({ onBack, onNavigateToRecords, onNavigateToCalendar }: ProfileScreenProps) {
  const menuItems = [
    { icon: ClipboardCheck, label: 'Анкета здоровья', count: null, color: 'text-teal-500' },
    { icon: Heart, label: 'Favorite Doctors', count: '3', color: 'text-red-500' },
    { icon: Bell, label: 'Notifications', count: null, color: 'text-blue-500' },
    { icon: CreditCard, label: 'Payment Method', count: null, color: 'text-green-500' },
    { icon: Settings, label: 'Settings', count: null, color: 'text-gray-500' },
    { icon: HelpCircle, label: 'Help Center', count: null, color: 'text-purple-500' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header with gradient background */}
      <div className="bg-gradient-to-br from-[#5B9FE3] to-[#4A8FD3] px-6 pt-6 pb-20 rounded-b-[40px]">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-xl font-bold text-white">Profile</h1>
          <button className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/30 transition-colors">
            <Bell size={20} className="text-white" />
          </button>
        </div>

        {/* Profile card */}
        <div className="bg-white rounded-3xl p-6 shadow-xl -mb-10">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full"></div>
              <button className="absolute bottom-0 right-0 w-7 h-7 bg-[#4A90D9] rounded-full flex items-center justify-center shadow-md border-2 border-white">
                <Camera size={14} className="text-white" />
              </button>
            </div>
            
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-900 mb-1">Monica Wood</h2>
              <p className="text-sm text-gray-500 mb-2">monica.wood@email.com</p>
              <div className="inline-block bg-blue-50 px-3 py-1 rounded-full">
                <span className="text-xs font-semibold text-[#4A90D9]">Premium Member</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
            <div className="text-center">
              <p className="text-2xl font-bold text-[#4A90D9]">12</p>
              <p className="text-xs text-gray-500 mt-1">Appointments</p>
            </div>
            <div className="text-center border-l border-r border-gray-100">
              <p className="text-2xl font-bold text-[#4A90D9]">8</p>
              <p className="text-xs text-gray-500 mt-1">Completed</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-[#4A90D9]">4</p>
              <p className="text-xs text-gray-500 mt-1">Upcoming</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu items */}
      <div className="px-6 mt-16">
        <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
          {menuItems.map((item, index) => (
            <button
              key={item.label}
              className={`w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors ${
                index !== menuItems.length - 1 ? 'border-b border-gray-100' : ''
              }`}
            >
              <div className={`w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center ${item.color}`}>
                <item.icon size={20} />
              </div>
              <span className="flex-1 text-left font-medium text-gray-700">{item.label}</span>
              {item.count && (
                <span className="w-6 h-6 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {item.count}
                </span>
              )}
              <ChevronRight size={20} className="text-gray-400" />
            </button>
          ))}
        </div>
      </div>

      {/* Logout button */}
      <div className="px-6 mt-6">
        <button className="w-full flex items-center justify-center gap-3 py-4 bg-red-50 rounded-3xl hover:bg-red-100 transition-colors">
          <LogOut size={20} className="text-red-500" />
          <span className="font-semibold text-red-500">Logout</span>
        </button>
      </div>

      {/* App version */}
      <div className="text-center mt-6">
        <p className="text-xs text-gray-400">Version 1.0.0</p>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 rounded-t-3xl shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button 
            onClick={onBack}
            className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600"
          >
            <Home size={20} />
          </button>
          <button 
            onClick={onNavigateToRecords}
            className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600"
          >
            <FileText size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600">
            <MessageCircle size={20} />
          </button>
          <button 
            onClick={onNavigateToCalendar}
            className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600"
          >
            <Calendar size={20} />
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-2 bg-[#4A90D9] text-white rounded-2xl">
            <User size={20} />
            <span className="text-xs font-medium">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}